import { FieldDefinition, fieldTypes } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Plus, Trash2, GripVertical } from "lucide-react";
import { nanoid } from "nanoid";

interface SchemaEditorProps {
  fields: FieldDefinition[];
  onFieldsChange: (fields: FieldDefinition[]) => void;
}

export function SchemaEditor({ fields, onFieldsChange }: SchemaEditorProps) {
  const addField = () => {
    const newField: FieldDefinition = {
      id: nanoid(),
      name: `field_${fields.length + 1}`,
      type: "string",
      required: true,
    };
    onFieldsChange([...fields, newField]);
  };

  const removeField = (id: string) => {
    onFieldsChange(fields.filter((f) => f.id !== id));
  };

  const updateField = (id: string, updates: Partial<FieldDefinition>) => {
    onFieldsChange(fields.map((f) => (f.id === id ? { ...f, ...updates } : f)));
  };

  return (
    <div className="space-y-4">
      {fields.map((field, index) => (
        <Card key={field.id} className="p-4">
          <div className="flex items-start gap-3">
            <button
              className="mt-8 cursor-grab hover-elevate p-1 rounded"
              data-testid={`button-drag-${index}`}
            >
              <GripVertical className="w-4 h-4 text-muted-foreground" />
            </button>

            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor={`field-name-${field.id}`} className="text-sm font-medium">
                  Field Name
                </Label>
                <Input
                  id={`field-name-${field.id}`}
                  value={field.name}
                  onChange={(e) => updateField(field.id, { name: e.target.value })}
                  placeholder="Enter field name"
                  data-testid={`input-field-name-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`field-type-${field.id}`} className="text-sm font-medium">
                  Data Type
                </Label>
                <Select
                  value={field.type}
                  onValueChange={(value) => updateField(field.id, { type: value as any })}
                >
                  <SelectTrigger id={`field-type-${field.id}`} data-testid={`select-field-type-${index}`}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {fieldTypes.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => removeField(field.id)}
              className="mt-8"
              data-testid={`button-remove-field-${index}`}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </Card>
      ))}

      <Button
        variant="outline"
        onClick={addField}
        className="w-full"
        data-testid="button-add-field"
      >
        <Plus className="w-4 h-4 mr-2" />
        Add Field
      </Button>
    </div>
  );
}
