import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { ExportFormat } from "@shared/schema";
import { Download, Loader2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";

interface ExportPanelProps {
  data: Record<string, any>[];
}

export function ExportPanel({ data }: ExportPanelProps) {
  const [format, setFormat] = useState<ExportFormat>("json");
  const [filename, setFilename] = useState("export");
  const { toast } = useToast();

  const exportMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/export", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ data, format, filename }),
      });
      
      if (!response.ok) throw new Error("Export failed");
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      
      const extension = format === "parquet" ? "parquet" : format;
      a.download = `${filename}.${extension}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      return true;
    },
    onSuccess: () => {
      toast({
        title: "Export successful",
        description: `Your data has been exported as ${format.toUpperCase()}`,
      });
    },
    onError: () => {
      toast({
        title: "Export failed",
        description: "Failed to export data. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleExport = () => {
    if (!filename.trim()) {
      toast({
        title: "Filename required",
        description: "Please enter a filename for your export",
        variant: "destructive",
      });
      return;
    }
    exportMutation.mutate();
  };

  return (
    <Card className="p-6">
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-medium mb-4">Export Data</h3>
          <p className="text-sm text-muted-foreground">
            Choose your preferred format and export {data.length} rows
          </p>
        </div>

        <div className="space-y-4">
          <div className="space-y-3">
            <Label className="text-sm font-medium">Export Format</Label>
            <RadioGroup value={format} onValueChange={(v) => setFormat(v as ExportFormat)}>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <label
                  htmlFor="format-json"
                  className={`flex items-center gap-3 p-4 border rounded-lg cursor-pointer hover-elevate active-elevate-2 ${
                    format === "json" ? "border-primary bg-primary/5" : ""
                  }`}
                  data-testid="label-format-json"
                >
                  <RadioGroupItem value="json" id="format-json" />
                  <div>
                    <p className="font-medium text-sm">JSON</p>
                    <p className="text-xs text-muted-foreground">.json</p>
                  </div>
                </label>

                <label
                  htmlFor="format-csv"
                  className={`flex items-center gap-3 p-4 border rounded-lg cursor-pointer hover-elevate active-elevate-2 ${
                    format === "csv" ? "border-primary bg-primary/5" : ""
                  }`}
                  data-testid="label-format-csv"
                >
                  <RadioGroupItem value="csv" id="format-csv" />
                  <div>
                    <p className="font-medium text-sm">CSV</p>
                    <p className="text-xs text-muted-foreground">.csv</p>
                  </div>
                </label>

                <label
                  htmlFor="format-xml"
                  className={`flex items-center gap-3 p-4 border rounded-lg cursor-pointer hover-elevate active-elevate-2 ${
                    format === "xml" ? "border-primary bg-primary/5" : ""
                  }`}
                  data-testid="label-format-xml"
                >
                  <RadioGroupItem value="xml" id="format-xml" />
                  <div>
                    <p className="font-medium text-sm">XML</p>
                    <p className="text-xs text-muted-foreground">.xml</p>
                  </div>
                </label>

                <label
                  htmlFor="format-parquet"
                  className={`flex items-center gap-3 p-4 border rounded-lg cursor-pointer hover-elevate active-elevate-2 ${
                    format === "parquet" ? "border-primary bg-primary/5" : ""
                  }`}
                  data-testid="label-format-parquet"
                >
                  <RadioGroupItem value="parquet" id="format-parquet" />
                  <div>
                    <p className="font-medium text-sm">Parquet</p>
                    <p className="text-xs text-muted-foreground">.parquet</p>
                  </div>
                </label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label htmlFor="filename" className="text-sm font-medium">
              Filename
            </Label>
            <Input
              id="filename"
              value={filename}
              onChange={(e) => setFilename(e.target.value)}
              placeholder="export"
              data-testid="input-filename"
            />
          </div>

          <Button
            onClick={handleExport}
            disabled={exportMutation.isPending || !filename.trim()}
            className="w-full"
            size="lg"
            data-testid="button-export"
          >
            {exportMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Exporting...
              </>
            ) : (
              <>
                <Download className="w-4 h-4 mr-2" />
                Export Data
              </>
            )}
          </Button>
        </div>
      </div>
    </Card>
  );
}
