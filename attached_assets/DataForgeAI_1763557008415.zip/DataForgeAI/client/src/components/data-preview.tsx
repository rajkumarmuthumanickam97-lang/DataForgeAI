import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FieldDefinition } from "@shared/schema";
import { RefreshCw } from "lucide-react";

interface DataPreviewProps {
  data: Record<string, any>[];
  fields: FieldDefinition[];
}

export function DataPreview({ data, fields }: DataPreviewProps) {
  const [currentPage, setCurrentPage] = useState(0);
  const rowsPerPage = 100;
  const totalPages = Math.ceil(data.length / rowsPerPage);
  const startRow = currentPage * rowsPerPage;
  const endRow = Math.min(startRow + rowsPerPage, data.length);
  const displayData = data.slice(startRow, endRow);

  const columnNames = fields.length > 0 
    ? fields.map(f => f.name)
    : data.length > 0 
    ? Object.keys(data[0]) 
    : [];

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-medium">Data Preview</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Showing rows {startRow + 1}-{endRow} of {data.length}
            </p>
          </div>
          <Button variant="outline" size="sm" data-testid="button-refresh-preview">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>

        <div className="border rounded-lg">
          <ScrollArea className="w-full">
            <div className="min-w-full">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs font-semibold uppercase tracking-wide w-16">
                      #
                    </TableHead>
                    {columnNames.map((col) => (
                      <TableHead
                        key={col}
                        className="text-xs font-semibold uppercase tracking-wide min-w-40"
                      >
                        {col}
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {displayData.map((row, idx) => (
                    <TableRow key={idx} className="hover-elevate" data-testid={`row-${idx}`}>
                      <TableCell className="font-mono text-xs text-muted-foreground">
                        {startRow + idx + 1}
                      </TableCell>
                      {columnNames.map((col) => (
                        <TableCell key={col} className="font-mono text-sm">
                          {row[col] !== null && row[col] !== undefined
                            ? String(row[col])
                            : "-"}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </ScrollArea>
        </div>

        {totalPages > 1 && (
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
              disabled={currentPage === 0}
              data-testid="button-prev-page"
            >
              Previous
            </Button>
            <span className="text-sm text-muted-foreground">
              Page {currentPage + 1} of {totalPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.min(totalPages - 1, currentPage + 1))}
              disabled={currentPage === totalPages - 1}
              data-testid="button-next-page"
            >
              Next
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
}
