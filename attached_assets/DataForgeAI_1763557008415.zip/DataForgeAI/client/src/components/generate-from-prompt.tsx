import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { FieldDefinition } from "@shared/schema";
import { Loader2, Sparkles } from "lucide-react";
import { SchemaEditor } from "./schema-editor";

interface GenerateFromPromptProps {
  fields: FieldDefinition[];
  onFieldsChange: (fields: FieldDefinition[]) => void;
  onDataGenerated: (data: Record<string, any>[]) => void;
  rowCount: number;
  onRowCountChange: (count: number) => void;
}

const examplePrompts = [
  "Generate customer data with name, email, phone, address, and signup date",
  "Create employee records with ID, name, department, salary, and hire date",
  "Generate product catalog with SKU, name, category, price, and stock quantity",
  "Create user profiles with username, email, age, country, and registration date",
];

export function GenerateFromPrompt({
  fields,
  onFieldsChange,
  onDataGenerated,
  rowCount,
  onRowCountChange,
}: GenerateFromPromptProps) {
  const [prompt, setPrompt] = useState("");
  const [showSchemaEditor, setShowSchemaEditor] = useState(false);
  const { toast } = useToast();

  const schemaMutation = useMutation({
    mutationFn: async (promptText: string) => {
      return await apiRequest("POST", "/api/generate-schema", { prompt: promptText }) as { fields: FieldDefinition[] };
    },
    onSuccess: (data) => {
      onFieldsChange(data.fields);
      setShowSchemaEditor(true);
      toast({
        title: "Schema generated",
        description: `Created ${data.fields.length} fields from your prompt`,
      });
    },
    onError: () => {
      toast({
        title: "Schema generation failed",
        description: "Please try rephrasing your prompt or check your API key",
        variant: "destructive",
      });
    },
  });

  const generateMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/generate-from-prompt", {
        prompt,
        rowCount,
      }) as { data: Record<string, any>[]; rowCount: number };
    },
    onSuccess: (data) => {
      onDataGenerated(data.data);
      toast({
        title: "Data generated successfully",
        description: `Generated ${data.rowCount} rows of data`,
      });
    },
    onError: () => {
      toast({
        title: "Generation failed",
        description: "Failed to generate data. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGenerateSchema = () => {
    if (prompt.trim().length < 10) {
      toast({
        title: "Prompt too short",
        description: "Please provide a more detailed description",
        variant: "destructive",
      });
      return;
    }
    schemaMutation.mutate(prompt);
  };

  const handleGenerateData = () => {
    if (fields.length === 0) {
      toast({
        title: "No schema defined",
        description: "Please generate a schema first",
        variant: "destructive",
      });
      return;
    }
    generateMutation.mutate();
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="prompt" className="text-sm font-medium">
              Describe the data you want to generate
            </Label>
            <Textarea
              id="prompt"
              placeholder="E.g., Generate customer data with full name, email address, phone number, shipping address, and account creation date..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="min-h-32 resize-none"
              data-testid="textarea-prompt"
            />
            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-foreground">
                {prompt.length} characters
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <Label className="text-sm font-medium">Example Prompts</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {examplePrompts.map((example, idx) => (
                <button
                  key={idx}
                  onClick={() => setPrompt(example)}
                  className="text-left p-3 rounded-lg border hover-elevate active-elevate-2 transition-colors text-sm"
                  data-testid={`button-example-${idx}`}
                >
                  {example}
                </button>
              ))}
            </div>
          </div>

          <Button
            onClick={handleGenerateSchema}
            disabled={schemaMutation.isPending || prompt.length < 10}
            className="w-full"
            size="lg"
            data-testid="button-generate-schema"
          >
            {schemaMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating Schema...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Generate Schema with AI
              </>
            )}
          </Button>
        </div>
      </Card>

      {showSchemaEditor && fields.length > 0 && (
        <Card className="p-6">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Generated Schema</h3>
              <Badge variant="secondary" data-testid="badge-field-count">
                {fields.length} fields
              </Badge>
            </div>

            <SchemaEditor fields={fields} onFieldsChange={onFieldsChange} />

            <div className="space-y-4 pt-4 border-t">
              <div className="space-y-2">
                <Label htmlFor="prompt-row-count" className="text-sm font-medium">
                  Number of Rows to Generate
                </Label>
                <div className="flex items-center gap-4">
                  <Slider
                    id="prompt-row-count"
                    min={10}
                    max={10000}
                    step={10}
                    value={[rowCount]}
                    onValueChange={(value) => onRowCountChange(value[0])}
                    className="flex-1"
                    data-testid="slider-prompt-row-count"
                  />
                  <Input
                    type="number"
                    min={10}
                    max={10000}
                    value={rowCount}
                    onChange={(e) => onRowCountChange(parseInt(e.target.value) || 100)}
                    className="w-24"
                    data-testid="input-prompt-row-count"
                  />
                </div>
              </div>

              <Button
                onClick={handleGenerateData}
                disabled={generateMutation.isPending}
                className="w-full"
                size="lg"
                data-testid="button-generate-prompt-data"
              >
                {generateMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating Data...
                  </>
                ) : (
                  <>
                    <span className="material-icons text-lg mr-2">auto_awesome</span>
                    Generate Data
                  </>
                )}
              </Button>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
