import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { FieldDefinition, fieldTypes } from "@shared/schema";
import { Upload, X, Loader2 } from "lucide-react";

interface UploadTemplateProps {
  onFieldsDetected: (fields: FieldDefinition[]) => void;
  onDataGenerated: (data: Record<string, any>[]) => void;
  rowCount: number;
  onRowCountChange: (count: number) => void;
}

export function UploadTemplate({
  onFieldsDetected,
  onDataGenerated,
  rowCount,
  onRowCountChange,
}: UploadTemplateProps) {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [detectedFields, setDetectedFields] = useState<FieldDefinition[]>([]);
  const { toast } = useToast();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("file", file);
      const response = await fetch("/api/upload-template", {
        method: "POST",
        body: formData,
      });
      if (!response.ok) throw new Error("Upload failed");
      return response.json() as Promise<{ fields: FieldDefinition[]; sampleData: any[]; rowCount: number }>;
    },
    onSuccess: (data) => {
      setDetectedFields(data.fields);
      onFieldsDetected(data.fields);
      toast({
        title: "File uploaded successfully",
        description: `Detected ${data.fields.length} fields from your template`,
      });
    },
    onError: () => {
      toast({
        title: "Upload failed",
        description: "Please ensure your file is a valid CSV or Excel file",
        variant: "destructive",
      });
    },
  });

  const generateMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/generate-from-template", {
        fields: detectedFields,
        rowCount,
      }) as { data: Record<string, any>[]; rowCount: number };
    },
    onSuccess: (data) => {
      onDataGenerated(data.data);
      toast({
        title: "Data generated successfully",
        description: `Generated ${data.rowCount} rows of data`,
      });
    },
    onError: () => {
      toast({
        title: "Generation failed",
        description: "Failed to generate data. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      const file = acceptedFiles[0];
      if (file) {
        setUploadedFile(file);
        uploadMutation.mutate(file);
      }
    },
    [uploadMutation]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "text/csv": [".csv"],
      "application/vnd.ms-excel": [".xls"],
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx"],
    },
    multiple: false,
  });

  const updateFieldType = (fieldId: string, newType: string) => {
    setDetectedFields((prev) =>
      prev.map((f) => (f.id === fieldId ? { ...f, type: newType as any } : f))
    );
    onFieldsDetected(
      detectedFields.map((f) => (f.id === fieldId ? { ...f, type: newType as any } : f))
    );
  };

  const removeFile = () => {
    setUploadedFile(null);
    setDetectedFields([]);
    onFieldsDetected([]);
  };

  return (
    <div className="space-y-6">
      {!uploadedFile ? (
        <Card className="p-6">
          <div
            {...getRootProps()}
            className={`min-h-64 border-2 border-dashed rounded-lg flex flex-col items-center justify-center p-8 transition-colors cursor-pointer ${
              isDragActive ? "border-primary bg-primary/5" : "border-border hover-elevate"
            }`}
            data-testid="dropzone-upload"
          >
            <input {...getInputProps()} data-testid="input-file" />
            <span className="material-icons text-6xl text-muted-foreground mb-4">cloud_upload</span>
            <p className="text-lg font-medium text-foreground mb-2">
              {isDragActive ? "Drop your file here" : "Drag & drop your template file"}
            </p>
            <p className="text-sm text-muted-foreground mb-4">
              Supports CSV and Excel (.xlsx, .xls) files
            </p>
            <Button variant="secondary" type="button" data-testid="button-browse">
              Browse Files
            </Button>
          </div>
        </Card>
      ) : (
        <>
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="material-icons text-primary text-2xl">description</span>
                <div>
                  <p className="font-medium text-foreground" data-testid="text-filename">
                    {uploadedFile.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {(uploadedFile.size / 1024).toFixed(2)} KB
                  </p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={removeFile}
                data-testid="button-remove-file"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </Card>

          {uploadMutation.isPending ? (
            <Card className="p-12">
              <div className="flex flex-col items-center gap-4">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
                <p className="text-sm text-muted-foreground">Analyzing your template...</p>
              </div>
            </Card>
          ) : detectedFields.length > 0 ? (
            <Card className="p-6">
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Detected Schema</h3>
                  <div className="border rounded-lg overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="text-xs font-semibold uppercase tracking-wide">
                            Field Name
                          </TableHead>
                          <TableHead className="text-xs font-semibold uppercase tracking-wide">
                            Data Type
                          </TableHead>
                          <TableHead className="text-xs font-semibold uppercase tracking-wide">
                            Sample Values
                          </TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {detectedFields.map((field) => (
                          <TableRow key={field.id}>
                            <TableCell className="font-medium">{field.name}</TableCell>
                            <TableCell>
                              <Select
                                value={field.type}
                                onValueChange={(value) => updateFieldType(field.id, value)}
                              >
                                <SelectTrigger className="w-40" data-testid={`select-type-${field.id}`}>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {fieldTypes.map((type) => (
                                    <SelectItem key={type} value={type}>
                                      {type}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </TableCell>
                            <TableCell className="font-mono text-sm text-muted-foreground">
                              {field.sampleValues?.slice(0, 3).join(", ")}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="row-count" className="text-sm font-medium">
                      Number of Rows to Generate
                    </Label>
                    <div className="flex items-center gap-4">
                      <Slider
                        id="row-count"
                        min={10}
                        max={10000}
                        step={10}
                        value={[rowCount]}
                        onValueChange={(value) => onRowCountChange(value[0])}
                        className="flex-1"
                        data-testid="slider-row-count"
                      />
                      <Input
                        type="number"
                        min={10}
                        max={10000}
                        value={rowCount}
                        onChange={(e) => onRowCountChange(parseInt(e.target.value) || 100)}
                        className="w-24"
                        data-testid="input-row-count"
                      />
                    </div>
                  </div>

                  <Button
                    onClick={() => generateMutation.mutate()}
                    disabled={generateMutation.isPending}
                    className="w-full"
                    size="lg"
                    data-testid="button-generate-data"
                  >
                    {generateMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Generating Data...
                      </>
                    ) : (
                      <>
                        <span className="material-icons text-lg mr-2">auto_awesome</span>
                        Generate Data
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </Card>
          ) : null}
        </>
      )}
    </div>
  );
}
