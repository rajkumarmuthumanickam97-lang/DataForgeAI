import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Settings } from "lucide-react";
import { UploadTemplate } from "@/components/upload-template";
import { GenerateFromPrompt } from "@/components/generate-from-prompt";
import { DataPreview } from "@/components/data-preview";
import { ExportPanel } from "@/components/export-panel";
import { FieldDefinition } from "@shared/schema";

export default function Home() {
  const [activeTab, setActiveTab] = useState<"upload" | "prompt">("upload");
  const [fields, setFields] = useState<FieldDefinition[]>([]);
  const [generatedData, setGeneratedData] = useState<Record<string, any>[]>([]);
  const [rowCount, setRowCount] = useState<number>(100);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="h-16 border-b flex items-center px-6 bg-card">
        <div className="flex items-center gap-3">
          <span className="material-icons text-primary text-3xl">data_object</span>
          <h1 className="text-xl font-semibold text-foreground">Universal ETL Data Creator</h1>
        </div>
        <div className="ml-auto">
          <Button variant="ghost" size="icon" data-testid="button-settings">
            <Settings className="w-5 h-5" />
          </Button>
        </div>
      </header>

      <main className="flex-1 overflow-auto">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "upload" | "prompt")} className="w-full">
            <TabsList className="w-full max-w-md mb-8" data-testid="tabs-input-mode">
              <TabsTrigger value="upload" className="flex-1" data-testid="tab-upload">
                <span className="material-icons text-lg mr-2">cloud_upload</span>
                Upload Template
              </TabsTrigger>
              <TabsTrigger value="prompt" className="flex-1" data-testid="tab-prompt">
                <span className="material-icons text-lg mr-2">auto_awesome</span>
                Generate from Prompt
              </TabsTrigger>
            </TabsList>

            <div className="space-y-8">
              <TabsContent value="upload" className="mt-0">
                <UploadTemplate
                  onFieldsDetected={setFields}
                  onDataGenerated={setGeneratedData}
                  rowCount={rowCount}
                  onRowCountChange={setRowCount}
                />
              </TabsContent>

              <TabsContent value="prompt" className="mt-0">
                <GenerateFromPrompt
                  fields={fields}
                  onFieldsChange={setFields}
                  onDataGenerated={setGeneratedData}
                  rowCount={rowCount}
                  onRowCountChange={setRowCount}
                />
              </TabsContent>

              {generatedData.length > 0 && (
                <div className="space-y-8">
                  <DataPreview data={generatedData} fields={fields} />
                  <ExportPanel data={generatedData} />
                </div>
              )}
            </div>
          </Tabs>
        </div>
      </main>

      <footer className="h-12 border-t bg-card flex items-center px-6">
        <p className="text-xs text-muted-foreground">
          Ready to export • {generatedData.length} rows generated
        </p>
      </footer>
    </div>
  );
}
