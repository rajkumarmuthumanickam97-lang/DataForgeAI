import { z } from "zod";

// Field data types supported by the system
export const fieldTypes = [
  "string",
  "number",
  "date",
  "boolean",
  "email",
  "phone",
  "address",
  "url",
  "uuid",
  "name",
  "company",
  "text",
] as const;

export type FieldType = typeof fieldTypes[number];

// Export formats supported
export const exportFormats = ["json", "csv", "xml", "parquet"] as const;
export type ExportFormat = typeof exportFormats[number];

// Schema for a single field definition
export const fieldDefinitionSchema = z.object({
  id: z.string(),
  name: z.string().min(1, "Field name is required"),
  type: z.enum(fieldTypes),
  format: z.string().optional(),
  required: z.boolean().default(true),
  sampleValues: z.array(z.any()).optional(),
});

export type FieldDefinition = z.infer<typeof fieldDefinitionSchema>;

// Schema for data generation request from template
export const generateFromTemplateSchema = z.object({
  fields: z.array(fieldDefinitionSchema),
  rowCount: z.number().min(10).max(10000),
  templateData: z.array(z.record(z.any())).optional(),
});

export type GenerateFromTemplateRequest = z.infer<typeof generateFromTemplateSchema>;

// Schema for data generation request from prompt
export const generateFromPromptSchema = z.object({
  prompt: z.string().min(10, "Prompt must be at least 10 characters"),
  rowCount: z.number().min(10).max(10000).default(100),
});

export type GenerateFromPromptRequest = z.infer<typeof generateFromPromptSchema>;

// Schema for export request
export const exportDataSchema = z.object({
  data: z.array(z.record(z.any())),
  format: z.enum(exportFormats),
  filename: z.string().min(1, "Filename is required"),
});

export type ExportDataRequest = z.infer<typeof exportDataSchema>;

// Response schema for schema detection
export const schemaDetectionResponseSchema = z.object({
  fields: z.array(fieldDefinitionSchema),
  sampleData: z.array(z.record(z.any())),
  rowCount: z.number(),
});

export type SchemaDetectionResponse = z.infer<typeof schemaDetectionResponseSchema>;

// Response schema for AI schema generation
export const aiSchemaResponseSchema = z.object({
  fields: z.array(fieldDefinitionSchema),
});

export type AISchemaResponse = z.infer<typeof aiSchemaResponseSchema>;

// Response schema for data generation
export const dataGenerationResponseSchema = z.object({
  data: z.array(z.record(z.any())),
  rowCount: z.number(),
});

export type DataGenerationResponse = z.infer<typeof dataGenerationResponseSchema>;
