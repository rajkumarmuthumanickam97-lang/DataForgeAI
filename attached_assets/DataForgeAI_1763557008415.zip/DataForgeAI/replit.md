# Universal ETL Data Creator

## Overview

A professional ETL data creation application that enables users to generate realistic sample datasets through two primary methods: uploading template files (CSV, XLSX, JSON) with automatic schema detection, or using AI-powered natural language prompts. The application supports exporting generated data in multiple formats (JSON, CSV, XML, Parquet) with configurable row counts from 10 to 10,000 records.

The system provides intelligent field type detection, inline schema editing, real-time data preview with pagination, and a clean, productivity-focused interface inspired by Linear's design aesthetic.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack**: React with TypeScript, using Vite as the build tool and development server.

**UI Framework**: Shadcn/ui components built on Radix UI primitives, styled with Tailwind CSS using a custom design system based on the "new-york" style variant.

**State Management**: TanStack Query (React Query) for server state management with infinite stale time and disabled automatic refetching, providing full control over data fetching. Client-side state uses React hooks (useState) for local component state.

**Routing**: Wouter for lightweight client-side routing, though the application is primarily single-page with tab-based navigation.

**Design System**: 
- Typography uses Inter for UI elements and JetBrains Mono for code/data display
- Spacing based on Tailwind's standardized units (2, 4, 6, 8, 12, 16)
- Custom color scheme with HSL-based CSS variables supporting both light and dark modes
- Material Icons for iconography

**Layout Pattern**: Fixed header with tabbed navigation (Upload Template vs Generate from Prompt), centered max-width content area (max-w-7xl), and fixed bottom status bar for notifications.

### Backend Architecture

**Runtime**: Node.js with Express.js framework

**Language**: TypeScript with ES modules

**API Design**: RESTful endpoints with JSON payloads:
- `/api/upload-template` - Multipart form upload for template files
- `/api/generate-schema` - AI schema generation from text prompts
- `/api/generate-data` - Data generation from field definitions
- `/api/export` - Data export in various formats

**File Processing**:
- XLSX files parsed using the `xlsx` library
- CSV files parsed using PapaParse
- JSON files parsed natively
- Automatic field type detection using pattern matching (email, phone, URL, date, number)

**Data Generation**: OpenAI GPT-5 integration for:
- Schema generation from natural language prompts
- Intelligent data generation matching field types and maintaining data realism
- JSON-structured responses with field definitions

**Export Formats**:
- JSON: Native serialization
- CSV: PapaParse builder
- XML: fast-xml-parser builder
- Parquet: parquetjs library for columnar data format

**Session Storage**: In-memory storage implementation (`MemStorage`) for temporary dataset and schema caching using Map data structures. Datasets and schemas identified by unique IDs (nanoid).

### Data Storage Solutions

**Database**: PostgreSQL configured via Drizzle ORM
- Connection via Neon serverless driver (`@neondatabase/serverless`)
- Schema defined in `shared/schema.ts`
- Migrations stored in `./migrations` directory
- Database provisioned through `DATABASE_URL` environment variable

**Session Management**: PostgreSQL-backed sessions using `connect-pg-simple` for persistent session storage.

**Temporary Storage**: In-memory Map-based storage for generated datasets and schemas during active user sessions. No persistent storage of generated data by design - data exists only during generation and export operations.

### External Dependencies

**AI Service**: OpenAI API (GPT-5 model) for:
- Natural language to schema conversion
- Intelligent synthetic data generation based on field types
- Requires `OPENAI_API_KEY` environment variable

**Database Service**: PostgreSQL database (Neon serverless recommended)
- Requires `DATABASE_URL` environment variable
- Used for session persistence and potential future data storage needs

**Third-Party Libraries**:
- **File Processing**: `xlsx`, `papaparse`, `fast-xml-parser`, `parquetjs`
- **File Upload**: `multer` for multipart form data handling
- **UI Components**: Comprehensive Radix UI component suite (@radix-ui/*)
- **Validation**: Zod for runtime type validation and schema definitions
- **Utilities**: `nanoid` for unique ID generation, `date-fns` for date manipulation
- **Type Safety**: Shared TypeScript schemas between client and server via `@shared` namespace

**Development Tools**:
- Replit-specific plugins for error overlay, dev banner, and cartographer (code mapping)
- TSX for TypeScript execution in development
- ESBuild for production bundling