import { FieldDefinition } from "@shared/schema";

export interface IStorage {
  // Store generated datasets temporarily
  saveDataset(id: string, data: Record<string, any>[]): Promise<void>;
  getDataset(id: string): Promise<Record<string, any>[] | undefined>;
  
  // Store schemas for reuse
  saveSchema(id: string, fields: FieldDefinition[]): Promise<void>;
  getSchema(id: string): Promise<FieldDefinition[] | undefined>;
}

export class MemStorage implements IStorage {
  private datasets: Map<string, Record<string, any>[]>;
  private schemas: Map<string, FieldDefinition[]>;

  constructor() {
    this.datasets = new Map();
    this.schemas = new Map();
  }

  async saveDataset(id: string, data: Record<string, any>[]): Promise<void> {
    this.datasets.set(id, data);
  }

  async getDataset(id: string): Promise<Record<string, any>[] | undefined> {
    return this.datasets.get(id);
  }

  async saveSchema(id: string, fields: FieldDefinition[]): Promise<void> {
    this.schemas.set(id, fields);
  }

  async getSchema(id: string): Promise<FieldDefinition[] | undefined> {
    return this.schemas.get(id);
  }
}

export const storage = new MemStorage();
