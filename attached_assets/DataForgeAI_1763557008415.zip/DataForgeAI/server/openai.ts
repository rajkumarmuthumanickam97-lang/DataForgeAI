import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function generateSchemaFromPrompt(prompt: string) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are a data schema expert. Based on the user's description, generate a JSON schema for data generation. 
          
Return a JSON object with a "fields" array. Each field should have:
- id: unique identifier (use simple numbers like "1", "2", "3")
- name: field name (snake_case)
- type: one of [string, number, date, boolean, email, phone, address, url, uuid, name, company, text]
- required: boolean (default true)

Example output:
{
  "fields": [
    {"id": "1", "name": "customer_name", "type": "name", "required": true},
    {"id": "2", "name": "email_address", "type": "email", "required": true},
    {"id": "3", "name": "phone_number", "type": "phone", "required": false}
  ]
}`,
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.fields || [];
  } catch (error) {
    console.error("OpenAI schema generation error:", error);
    throw new Error("Failed to generate schema from prompt");
  }
}

export async function generateDataFromFields(
  fields: Array<{ name: string; type: string }>,
  rowCount: number,
  templateData?: Array<Record<string, any>>
) {
  try {
    const fieldDescriptions = fields.map(f => `${f.name} (${f.type})`).join(", ");
    
    let promptText = `Generate ${rowCount} rows of realistic sample data with these fields: ${fieldDescriptions}.`;
    
    if (templateData && templateData.length > 0) {
      const samples = templateData.slice(0, 3).map(row => 
        fields.map(f => `${f.name}: ${row[f.name]}`).join(", ")
      ).join("; ");
      promptText += ` Use these sample patterns: ${samples}.`;
    }
    
    promptText += ` Return as JSON with a "data" array containing ${rowCount} objects. Each object should have all fields with realistic values matching their types.`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are a synthetic data generator. Generate realistic sample data based on field specifications.
          
Rules:
- Generate exactly the requested number of rows
- Use realistic, varied values
- For dates, use ISO format (YYYY-MM-DD)
- For booleans, use true/false
- For numbers, use appropriate ranges
- For emails, use realistic formats
- For phones, use format: (555) 555-5555
- For addresses, use complete US addresses
- Make data diverse and realistic

Return JSON: {"data": [array of objects]}`,
        },
        {
          role: "user",
          content: promptText,
        },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 8192,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.data || [];
  } catch (error) {
    console.error("OpenAI data generation error:", error);
    throw new Error("Failed to generate data");
  }
}

export async function generateDataFromPrompt(prompt: string, rowCount: number) {
  try {
    const schemaResponse = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are a synthetic data generator. Based on the description, generate realistic sample data.
          
First, infer the data structure from the prompt. Then generate ${rowCount} rows of realistic data.

Return JSON: {"data": [array of objects with the inferred fields]}`,
        },
        {
          role: "user",
          content: `${prompt}\n\nGenerate exactly ${rowCount} rows of data.`,
        },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 8192,
    });

    const result = JSON.parse(schemaResponse.choices[0].message.content || "{}");
    return result.data || [];
  } catch (error) {
    console.error("OpenAI prompt-based generation error:", error);
    throw new Error("Failed to generate data from prompt");
  }
}
