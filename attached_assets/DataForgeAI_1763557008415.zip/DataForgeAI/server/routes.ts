import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import * as XLSX from "xlsx";
import Papa from "papaparse";
import { XMLBuilder } from "fast-xml-parser";
import parquet from "parquetjs";
import { storage } from "./storage";
import {
  generateSchemaFromPrompt,
  generateDataFromFields,
  generateDataFromPrompt,
} from "./openai";
import {
  generateFromTemplateSchema,
  generateFromPromptSchema,
  exportDataSchema,
  FieldDefinition,
} from "@shared/schema";
import { nanoid } from "nanoid";
import { createWriteStream } from "fs";
import { tmpdir } from "os";
import { join } from "path";
import { readFileSync, unlinkSync } from "fs";

const upload = multer({ storage: multer.memoryStorage() });

function detectFieldType(values: any[]): string {
  const nonNullValues = values.filter((v) => v !== null && v !== undefined && v !== "");
  if (nonNullValues.length === 0) return "string";

  const sample = nonNullValues[0];
  
  if (typeof sample === "boolean") return "boolean";
  if (typeof sample === "number") return "number";
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const dateRegex = /^\d{4}-\d{2}-\d{2}|^\d{1,2}\/\d{1,2}\/\d{2,4}/;
  const phoneRegex = /^\+?1?\s*\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/;
  const urlRegex = /^https?:\/\//;
  
  const stringSample = String(sample);
  
  if (emailRegex.test(stringSample)) return "email";
  if (urlRegex.test(stringSample)) return "url";
  if (dateRegex.test(stringSample)) return "date";
  if (phoneRegex.test(stringSample)) return "phone";
  if (stringSample.toLowerCase() === "true" || stringSample.toLowerCase() === "false") return "boolean";
  if (!isNaN(Number(stringSample)) && stringSample.length < 15) return "number";
  
  return "string";
}

function parseCSV(buffer: Buffer): { data: Record<string, any>[]; fields: FieldDefinition[] } {
  const text = buffer.toString("utf-8");
  const parsed = Papa.parse(text, { header: true, skipEmptyLines: true });
  const data = parsed.data as Record<string, any>[];
  
  if (data.length === 0) {
    throw new Error("No data found in CSV file");
  }
  
  const headers = Object.keys(data[0]);
  const fields: FieldDefinition[] = headers.map((name, idx) => {
    const values = data.slice(0, 100).map((row) => row[name]);
    const type = detectFieldType(values);
    const sampleValues = values.filter((v) => v).slice(0, 5);
    
    return {
      id: String(idx + 1),
      name,
      type: type as any,
      required: true,
      sampleValues,
    };
  });
  
  return { data, fields };
}

function parseExcel(buffer: Buffer): { data: Record<string, any>[]; fields: FieldDefinition[] } {
  const workbook = XLSX.read(buffer, { type: "buffer" });
  const sheetName = workbook.SheetNames[0];
  const sheet = workbook.Sheets[sheetName];
  const data = XLSX.utils.sheet_to_json(sheet) as Record<string, any>[];
  
  if (data.length === 0) {
    throw new Error("No data found in Excel file");
  }
  
  const headers = Object.keys(data[0]);
  const fields: FieldDefinition[] = headers.map((name, idx) => {
    const values = data.slice(0, 100).map((row) => row[name]);
    const type = detectFieldType(values);
    const sampleValues = values.filter((v) => v).slice(0, 5);
    
    return {
      id: String(idx + 1),
      name,
      type: type as any,
      required: true,
      sampleValues,
    };
  });
  
  return { data, fields };
}

async function exportToJSON(data: Record<string, any>[]): Promise<Buffer> {
  return Buffer.from(JSON.stringify(data, null, 2), "utf-8");
}

async function exportToCSV(data: Record<string, any>[]): Promise<Buffer> {
  const csv = Papa.unparse(data);
  return Buffer.from(csv, "utf-8");
}

async function exportToXML(data: Record<string, any>[]): Promise<Buffer> {
  const builder = new XMLBuilder({
    ignoreAttributes: false,
    format: true,
  });
  
  const xmlData = {
    data: {
      record: data,
    },
  };
  
  const xml = builder.build(xmlData);
  return Buffer.from(xml, "utf-8");
}

async function exportToParquet(data: Record<string, any>[]): Promise<Buffer> {
  if (data.length === 0) {
    throw new Error("No data to export");
  }
  
  const schemaFields: Record<string, any> = {};
  const firstRow = data[0];
  
  Object.keys(firstRow).forEach((key) => {
    const value = firstRow[key];
    if (typeof value === "number") {
      schemaFields[key] = { type: "DOUBLE" };
    } else if (typeof value === "boolean") {
      schemaFields[key] = { type: "BOOLEAN" };
    } else {
      schemaFields[key] = { type: "UTF8" };
    }
  });
  
  const schema = new parquet.ParquetSchema(schemaFields);
  const tempFile = join(tmpdir(), `export-${nanoid()}.parquet`);
  const writer = await parquet.ParquetWriter.openFile(schema, tempFile);
  
  for (const row of data) {
    await writer.appendRow(row);
  }
  
  await writer.close();
  
  const buffer = readFileSync(tempFile);
  unlinkSync(tempFile);
  
  return buffer;
}

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/upload-template", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      
      const { buffer, originalname } = req.file;
      let result: { data: Record<string, any>[]; fields: FieldDefinition[] };
      
      if (originalname.endsWith(".csv")) {
        result = parseCSV(buffer);
      } else if (originalname.endsWith(".xlsx") || originalname.endsWith(".xls")) {
        result = parseExcel(buffer);
      } else {
        return res.status(400).json({ error: "Unsupported file format" });
      }
      
      const datasetId = nanoid();
      await storage.saveDataset(datasetId, result.data);
      
      res.json({
        fields: result.fields,
        sampleData: result.data.slice(0, 10),
        rowCount: result.data.length,
        datasetId,
      });
    } catch (error: any) {
      console.error("Upload error:", error);
      res.status(500).json({ error: error.message || "Failed to process file" });
    }
  });

  app.post("/api/generate-schema", async (req, res) => {
    try {
      const { prompt } = req.body;
      
      if (!prompt || prompt.length < 10) {
        return res.status(400).json({ error: "Prompt must be at least 10 characters" });
      }
      
      const fields = await generateSchemaFromPrompt(prompt);
      
      res.json({ fields });
    } catch (error: any) {
      console.error("Schema generation error:", error);
      res.status(500).json({ error: error.message || "Failed to generate schema" });
    }
  });

  app.post("/api/generate-from-template", async (req, res) => {
    try {
      const result = generateFromTemplateSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      
      const { fields, rowCount, templateData } = result.data;
      
      const data = await generateDataFromFields(fields, rowCount, templateData);
      
      res.json({ data, rowCount: data.length });
    } catch (error: any) {
      console.error("Data generation error:", error);
      res.status(500).json({ error: error.message || "Failed to generate data" });
    }
  });

  app.post("/api/generate-from-prompt", async (req, res) => {
    try {
      const result = generateFromPromptSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      
      const { prompt, rowCount } = result.data;
      
      const data = await generateDataFromPrompt(prompt, rowCount);
      
      res.json({ data, rowCount: data.length });
    } catch (error: any) {
      console.error("Prompt generation error:", error);
      res.status(500).json({ error: error.message || "Failed to generate data" });
    }
  });

  app.post("/api/export", async (req, res) => {
    try {
      const result = exportDataSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ error: "Invalid export request" });
      }
      
      const { data, format, filename } = result.data;
      
      let buffer: Buffer;
      let contentType: string;
      let extension: string;
      
      switch (format) {
        case "json":
          buffer = await exportToJSON(data);
          contentType = "application/json";
          extension = "json";
          break;
        case "csv":
          buffer = await exportToCSV(data);
          contentType = "text/csv";
          extension = "csv";
          break;
        case "xml":
          buffer = await exportToXML(data);
          contentType = "application/xml";
          extension = "xml";
          break;
        case "parquet":
          buffer = await exportToParquet(data);
          contentType = "application/octet-stream";
          extension = "parquet";
          break;
        default:
          return res.status(400).json({ error: "Unsupported export format" });
      }
      
      res.setHeader("Content-Type", contentType);
      res.setHeader("Content-Disposition", `attachment; filename="${filename}.${extension}"`);
      res.send(buffer);
    } catch (error: any) {
      console.error("Export error:", error);
      res.status(500).json({ error: error.message || "Failed to export data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
