# Design Guidelines: Universal ETL Data Creation Application

## Design Approach
**System-Based Design** inspired by Linear's clean productivity aesthetic combined with Material Design's robust data handling patterns. This creates a professional, efficiency-focused interface optimized for complex ETL workflows and data manipulation tasks.

## Typography System
- **Primary Font**: Inter (Google Fonts) for UI elements, forms, and data tables
- **Monospace Font**: JetBrains Mono for data preview, code snippets, and schema definitions
- **Hierarchy**:
  - Page titles: text-2xl font-semibold
  - Section headers: text-lg font-medium
  - Form labels: text-sm font-medium
  - Body text: text-sm font-normal
  - Table headers: text-xs font-semibold uppercase tracking-wide
  - Data cells: text-sm font-mono

## Layout System
**Spacing Units**: Tailwind units of 2, 4, 6, 8, 12, and 16 for consistent rhythm
- Component padding: p-4 to p-6
- Section spacing: space-y-6 to space-y-8
- Card padding: p-6
- Form field gaps: gap-4
- Table cell padding: px-4 py-3

## Application Structure

### Main Layout
- **Fixed Header**: Full-width app header with logo, application title, and settings icon (h-16)
- **Tabbed Navigation**: Horizontal tabs below header for "Upload Template" and "Generate from Prompt" modes
- **Content Area**: Single scrollable content area (no sidebar) with max-w-7xl container centered
- **Status Bar**: Fixed bottom notification area for export status and processing feedback (h-12)

### Upload Template Mode

**File Upload Zone** (Primary Component):
- Large dropzone area (min-h-64) with dashed border treatment
- Center-aligned upload icon (size-16) from Material Icons
- Upload instructions and supported formats text
- File selection button positioned below icon
- Active drag state visual feedback
- Uploaded file preview card with filename, size, remove action

**Schema Detection Panel**:
- Auto-detected fields displayed in data table format
- Columns: Field Name, Detected Type, Sample Values, Actions
- Inline type override dropdowns for each field
- Row count input with slider control (10-10,000 range)
- "Generate Data" primary action button

### Generate from Prompt Mode

**Prompt Interface**:
- Large textarea input (min-h-32) with placeholder guidance
- Character count indicator below textarea
- Example prompts section with clickable templates (grid of 2 columns)
- "Generate Schema" primary action button
- Loading state with progress indicator

**Generated Schema Editor**:
- Field configuration cards in vertical stack
- Each card contains: field name input, type selector dropdown, format options
- Add/Remove field actions with icon buttons
- Drag handles for reordering fields
- Row count control matching Upload mode

### Data Preview Section

**Preview Table** (Shared Component):
- Full-width responsive table with horizontal scroll
- Fixed header row with sort controls
- Pagination controls (showing rows 1-100 of total)
- Row highlighting on hover
- Monospace font for all data cells
- Column resize handles
- "Refresh Preview" action button

### Export Panel

**Format Selection**:
- Radio button group for format selection (JSON, CSV, XML, Parquet)
- Format-specific options in expandable sections
- File naming input field
- Large "Export Data" primary button with download icon
- Export history list showing last 5 exports with re-download links

## Component Library

### Buttons
- **Primary**: Solid background, rounded-lg, px-6 py-3, font-medium
- **Secondary**: Border treatment, rounded-lg, px-6 py-3
- **Icon Buttons**: Square (w-10 h-10), rounded-md, centered icon
- All buttons include appropriate Material Icons

### Forms
- **Input Fields**: Full-width, rounded-md, border treatment, px-4 py-2.5, focus ring
- **Dropdowns**: Matching input styling with chevron-down icon
- **Labels**: mb-2 spacing, font-medium
- **Help Text**: text-xs, mt-1.5 below inputs

### Cards
- Border treatment, rounded-lg, p-6
- Shadow on hover for interactive cards
- Header section with title and actions

### Tables
- Border-collapse design
- Alternating row treatment for readability
- Sticky header with shadow on scroll
- Cell padding: px-4 py-3
- Responsive horizontal scroll wrapper

### Icons
**Material Icons** (via CDN) for all interface icons:
- Upload: cloud_upload
- Download: download
- Add: add
- Remove: delete
- Settings: settings
- Refresh: refresh
- Drag: drag_indicator

## Interaction Patterns
- Immediate visual feedback for file drops and form interactions
- Loading skeletons for data generation and preview updates
- Toast notifications for success/error states in bottom-right
- Smooth tab transitions without page reload
- Disabled states for buttons during processing
- Progressive disclosure for advanced options (collapsed by default)

## Responsive Breakpoints
- Mobile (<768px): Single column, stacked cards, simplified table view
- Tablet (768px-1024px): Two-column grids where applicable
- Desktop (>1024px): Full multi-column layouts with optimized table widths

This design prioritizes data density, workflow efficiency, and professional aesthetics suitable for technical ETL users while maintaining clarity and usability across complex data manipulation tasks.